[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/YwAx6yNc)
<img width="1401" alt="4 17" src="https://github.com/wsu-cs540-fall2023/cs-540-hw-2-R246N642/assets/123512126/5abead10-7ec9-4e35-8151-bb36aa8de833">
<img width="643" alt="4 21" src="https://github.com/wsu-cs540-fall2023/cs-540-hw-2-R246N642/assets/123512126/2de55f75-48ce-4b6a-822e-ef2f2a2bf51e">
