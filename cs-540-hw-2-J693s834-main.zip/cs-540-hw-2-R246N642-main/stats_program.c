#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 3

int num_values;
int *values;
double average_value;
int minimum_value;
int maximum_value;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void *calculate_average(void *arg) {
    int sum = 0;
    for (int i = 0; i < num_values; i++) {
        sum += values[i];
    }
    pthread_mutex_lock(&mutex);
    average_value = (double)sum / num_values;
    pthread_mutex_unlock(&mutex);
    pthread_exit(NULL);
}

void *calculate_minimum(void *arg) {
    int min = values[0];
    for (int i = 1; i < num_values; i++) {
        if (values[i] < min) {
            min = values[i];
        }
    }
    pthread_mutex_lock(&mutex);
    minimum_value = min;
    pthread_mutex_unlock(&mutex);
    pthread_exit(NULL);
}

void *calculate_maximum(void *arg) {
    int max = values[0];
    for (int i = 1; i < num_values; i++) {
        if (values[i] > max) {
            max = values[i];
        }
    }
    pthread_mutex_lock(&mutex);
    maximum_value = max;
    pthread_mutex_unlock(&mutex);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <list of numbers>\n", argv[0]);
        return 1;
    }

    num_values = argc - 1;
    values = (int *)malloc(num_values * sizeof(int));
    for (int i = 0; i < num_values; i++) {
        values[i] = atoi(argv[i + 1]);
    }

    pthread_t threads[NUM_THREADS];
    pthread_create(&threads[0], NULL, calculate_average, NULL);
    pthread_create(&threads[1], NULL, calculate_minimum, NULL);
    pthread_create(&threads[2], NULL, calculate_maximum, NULL);

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("The average value is %.2lf\n", average_value);
    printf("The minimum value is %d\n", minimum_value);
    printf("The maximum value is %d\n", maximum_value);

    free(values);

    return 0;
}
